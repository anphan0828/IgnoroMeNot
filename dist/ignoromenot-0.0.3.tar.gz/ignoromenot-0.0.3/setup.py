from setuptools import setup, find_packages
import codecs
import os

VERSION = '0.0.3'

def read_file(filename):
    with open(os.path.join(os.path.dirname(__file__), filename)) as file:
        return file.read()

# Setting up
setup(
        name="ignoromenot",
        version=VERSION,
        author="An Phan",
        author_email="<ahphan@iastate.edu>",
        description="Ignorome finder",
        long_description=read_file('README.md'),
        long_description_content_type = 'text/markdown',
        packages=find_packages(),
        install_requires=[],
        classifiers = [
            "Programming Language :: Python :: 3",
            "License :: OSI Approved :: GNU General Public License v3 (GPLv3)",
            "Operating System :: OS Independent",
        ]
)


